function submitForm(form){
	alert(form);
//	document.forms[formName].submit();
	form.submit();
}

function checkAllDistributers(button) {
	alert(button);
	var form = $(button.form);
    var inputs = form.getInputs('checkbox');
    inputs.each(function (elem) {
    	elem.checked = true;
    });
}
/*
function checkAllDistributers(source) {
	alert(source);
  checkboxes = document.getElementsByName('chkDistributer');
  alert(checkboxes);
//  for(var i in checkboxes)
  //  checkboxes[i].checked = source.checked;
}

*/