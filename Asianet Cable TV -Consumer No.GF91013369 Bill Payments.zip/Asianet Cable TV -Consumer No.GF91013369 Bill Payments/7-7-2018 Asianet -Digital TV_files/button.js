
function createMenu( appPath,imgPath){
	createMenu_1( 1, 1, 1, appPath, imgPath);
	/*
stm_bm(["menu367a",400,"",imgPath+"/blank.gif",0,"","",0,0,250,0,1000,1,0,0,""],this);
stm_bp("p0",[0,4,0,0,0,0,0,0,100,"",-2,"",-2,50,0,0,"#fffff7","transparent","",3,0,0,"#000000"]);
stm_ai("p0i0",[0,"  Broadcaster  ","","",-1,-1,0,appPath+"home/broadcasterindex","_self","","","","",0,0,0,"","",0,0,0,0,1,"#fffff7",1,"#b5bed6",1,"","",3,3,0,0,"#fffff7","#000000","#ffffff","#ff0097","bold 11px Tahoma, Arial, Verdana","bold 11px Tahoma, Arial, Verdana",0,0]);  
stm_ai("p0i1",[6,1,"#0000cc",imgPath+"/sep.gif",2,31,0]);
stm_aix("p0i2","p0i0",[0,"  Employee  ","","",-1,-1,0,appPath+"home/employeeindex","_self","","","","",0,0,0,imgPath+"/arrow_r.gif"]);
stm_bpx("p1","p0",[1,4,0,12,2,2,0,0,100,"",-2,"",-2,50,0,0,"#fffff7","#5098ea"]);
stm_ep();
stm_aix("p0i3","p0i1",[]);
stm_aix("p0i4","p0i0",[0,"  Register Now  ","","",-1,-1,0,appPath+"home/register"],209,0);
stm_ep();
stm_em();
*/
}

function createMenu_1( employeeLoginEnabled, broadcasterLoginEnabled, registerNowEnabled, appPath, imgPath)
{
	stm_bm(["menu367a",400,"",imgPath+"/blank.gif",0,"","",0,0,250,0,1000,1,0,0,""],this);
	stm_bp("p0",[0,4,0,0,0,0,0,0,100,"",-2,"",-2,50,0,0,"#fffff7","transparent","",3,0,0,"#000000"]);

	if ( broadcasterLoginEnabled > 0 )
	{
		stm_ai("p0i0",[0,"  Broadcaster  ","","",-1,-1,0,appPath+"home/broadcasterindex","_self","","","","",0,0,0,"","",0,0,0,0,1,"#fffff7",1,"#b5bed6",1,"","",3,3,0,0,"#fffff7","#000000","#ffffff","#ff0097","bold 11px Tahoma, Arial, Verdana","bold 11px Tahoma, Arial, Verdana",0,0]);
		if ( (employeeLoginEnabled > 0)  || (registerNowEnabled > 0) )
		{
			stm_ai("p0i1",[6,1,"#0000cc",imgPath+"/sep.gif",2,31,0]);
		}
		else
		{
			stm_ai("p0i1",[6,1,"", "",2,31,0]);
		}
	}
	else
	{
		stm_ai("p0i0",[0," ","","",-1,-1,0,"","_self","","","","",0,0,0,"","",0,0,0,0,1,"#fffff7",1,"#b5bed6",1,"","",3,3,0,0,"#fffff7","#000000","#ffffff","#ff0097","bold 11px Tahoma, Arial, Verdana","bold 11px Tahoma, Arial, Verdana",0,0]);  
		stm_ai("p0i1",[6,1,"", "",2,31,0]);
	}
	
	if ( employeeLoginEnabled > 0 )
	{
		stm_aix("p0i2","p0i0",[0,"  Employee  ","","",-1,-1,0,appPath+"home/employeeindex","_self","","","","",0,0,0,imgPath+"/arrow_r.gif"]);
		if ( (registerNowEnabled > 0) )
		{
			stm_ai("p0i3",[6,1,"#0000cc",imgPath+"/sep.gif",2,31,0]);
		}
		else
		{
			stm_ai("p0i3",[6,1,"", "",2,31,0]);
		}
	}
	else
	{
		stm_aix("p0i2","p0i0",[0," ","","",-1,-1,0,"","_self","","","","",0,0,0,""]);
		stm_ai("p0i3",[6,1,"", "",2,31,0]);
	}
	
	stm_bpx("p1","p0",[1,4,0,12,2,2,0,0,100,"",-2,"",-2,50,0,0,"#fffff7","#5098ea"]);
	stm_ep();

	if ( registerNowEnabled > 0 )
	{
		stm_aix("p0i4","p0i0",[0,"  Register Now  ","","",-1,-1,0,appPath+"home/register"],209,0);
	}
	else
	{
		stm_aix("p0i4","p0i0",[0," ","","",-1,-1,0,""],209,0);
	}
	stm_ep();
	stm_em();
}


function distributorSubMenu(appPath,imgPath,diststatus){
stm_bm(["menu0061",850,"","blank.gif",0,"","",0,0,250,0,1000,1,0,0,"","",0,0,1,1,"default","hand",""],this);
stm_bp("p0",[1,4,0,0,1,7,0,0,100,"",-2,"",-2,50,0,0,"#FFFFF7","transparent","",3,0,0,"#000000"]);
stm_ai("p0i0",[0,"      Daily Report                        ","","",-1,-1,0,appPath+"distributer/dailyReport","_self","","","","",0,0,0,"","",0,0,0,0,1,"#FFFFF7",1,"#B5BED6",1,imgPath+"/leftbuts.gif",imgPath+"/leftbuts.gif",3,3,0,0,"#FFFFF7","#000000","#4C4C4C","#FF6600","bold 12px 'Tahoma','Verdana'","bold 12px 'Tahoma','Verdana'",0,0],209,0);
stm_aix("p0i1","p0i0",[0,"      Monthly Report","","",-1,-1,0,appPath+"distributer/monthlyReport"],209,0);
stm_aix("p0i2","p0i0",[0,"      Summary Report","","",-1,-1,0,appPath+"distributer/summaryReport"],209,0);
if(diststatus==1)
stm_aix("p0i3","p0i0",[0,"      Consumer Booking","","",-1,-1,0,appPath+"distributer/walkinBooking"],209,0);
stm_aix("p0i4","p0i0",[0,"      Consumer Search","","",-1,-1,0,appPath+"distributer/consumerSearch"],209,0);
stm_aix("p0i5","p0i0",[0,"      Complaints","","",-1,-1,0,"","_self","","","","",0,0,0,"","",-1,-1],209,0);
stm_bpx("p1","p0",[1,2,0,-1,1,7,0,0,100,"progid:DXImageTransform.Microsoft.Wipe(GradientSize=1.0,wipeStyle=0,motion=forward,enabled=0,Duration=0.85)",6,"progid:DXImageTransform.Microsoft.Wipe(GradientSize=1.0,wipeStyle=0,motion=reverse,enabled=0,Duration=0.85)",7,25]);
stm_aix("p1i0","p0i0",[0,"Complaints Report             ","","",-1,-1,0,appPath+"distributer/complaintsReport","_self","","","","",0,0,0,"","",0,0,0,0,1,"#5071C5",1,"#FF6000",1,imgPath+"/subback.gif",imgPath+"/subbackovr.gif",3,3,1,1,"#8DB3E9","#8DB3E9","#FFFFFF","#FFFFFF","bold 11px 'Tahoma','Verdana'","bold 11px 'Tahoma','Verdana'"]);
stm_aix("p1i1","p1i0",[0,"Complaints Closure","","",-1,-1,0,appPath+"distributer/complaintsClosure"]);
stm_ep();
stm_aix("p0i6","p0i5",[0,"      Plant Load Dispatch"],209,0);
stm_bpx("p2","p1",[]);
stm_aix("p2i0","p1i0",[0,"Daily Report                  ","","",-1,-1,0,appPath+"distributer/home"]);
stm_aix("p2i1","p1i0",[0,"Monthly Report                ","","",-1,-1,0,appPath+"distributer/home"]);
stm_aix("p2i2","p2i1",[0,"Summary Report                ","","",-1,-1,0,appPath+"distributer/home"]);
stm_ep();
stm_aix("p0i7","p0i0",[0,"      FWP Complaints","","",-1,-1,0,appPath+"distributer/FWPComplaintfeedback"],209,0);
stm_ep();
stm_aix("p0i8","p0i0",[0,"      Feedback","","",-1,-1,0,appPath+"distributer/feedback"],209,0);
stm_ep();
stm_aix("p0i9","p0i0",[0,"      Change Password","","",-1,-1,0,appPath+"distributer/changePassword"],209,0);
stm_ep();
stm_em();
}
