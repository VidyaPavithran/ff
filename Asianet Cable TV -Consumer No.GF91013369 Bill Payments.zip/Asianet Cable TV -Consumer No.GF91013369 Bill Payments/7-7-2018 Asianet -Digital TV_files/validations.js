// JavaScript Document
function ajaxRequest(url,resDivID){
	if (window.XMLHttpRequest){
		// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{
		// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200){
		    document.getElementById(resDivID).innerHTML=xmlhttp.responseText;
    	}
  	}
	xmlhttp.open("GET",url,true);
	xmlhttp.send();

}

function getHTTPObject() 
{
    var xmlhttp;
    if (window.XMLHttpRequest)
	{
        xmlhttp = new XMLHttpRequest();
    }
	else if (window.ActiveXObject)
	{
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    return xmlhttp;
}


function loadXMLString(txt)
{
if (window.DOMParser)
  {
  parser=new DOMParser();
  xmlDoc=parser.parseFromString(txt,"text/xml");
  }
else // Internet Explorer
  {
  xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
  xmlDoc.async="false";
  xmlDoc.loadXML(txt);
  }
return xmlDoc;
}

function capLock(e){
 kc = e.keyCode?e.keyCode:e.which;
 sk = e.shiftKey?e.shiftKey:((kc == 16)?true:false);
 if(((kc >= 65 && kc <= 90) && !sk)||((kc >= 97 && kc <= 122) && sk))
 document.getElementById("error").innerHTML="Caps Lock is on";
 else
 document.getElementById("error").innerHTML="";
}

function CheckAll(chk,chkall)
{
            if (chkall.checked)
            {
				chk.checked = true;
				
                for(var i=0;i<chk.length;i++) 
				{
                  chk[i].checked = true;
				  
                }
            }
            else 
            {
				chk.checked = false;
				for(var i=0;i<chk.length;i++) 
				{
                  chk[i].checked = false;
				  
                }
            }
}

//function used for entering Numbers only.
function checkNum(evt)
{
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
}

//function used for entering Numbers with decimal point  only.
function checkdecimalNum(evt)
{
         var charCode = (evt.which) ? evt.which : event.keyCode
		 if (charCode > 31 && (charCode < 48 || charCode > 57) && charCode!=46)
            return false;

         return true;
}

function imposeMaxLength(Object, MaxLen)
{
  return (Object.value.length <= MaxLen);
}

function trim(str)
{
   return str.replace(/^[\s]+/,'').replace(/[\s]+$/,'').replace(/[\s]{2,}/,' ');
}

function reloadthis() {
		/*if(document.forms[0].guestmsgreq.value == "false"){

				if(document.forms[0].checkClose.value == '0'){
						validateLogout();
						document.forms[0].submit();*/
						alert('You have successfully logged off');
		//		}
		
		//}
}

function addtoMyCart(service,url,form){
	
	
	xmlhttp=getHTTPObject();
	
	xmlhttp.onreadystatechange=function(){
				//alert(xmlhttp.status);
		if (xmlhttp.readyState==4 && xmlhttp.status==200){

			var doc = loadXMLString(trim(xmlhttp.responseText));   // Create & Assign the XML file to a var
			
			var totchilds=doc.getElementsByTagName("Service").length;
			

		//	for (i=0;i<totchilds;i++){
				var val=doc.getElementsByTagName("DistributerName")[0].childNodes[0].nodeValue;
				alert("-----"+val+"---");
				form.balamount.value="HIIIII";
				document.getElementById('balamount').innerHTML='Zkjbasjdsabdnsad';
				//val=val.replace(/`/g,"&");
				//var temp = new Option(val,val);
				//distributer.options[distributer.options.length]=temp;
			//}
			
    	}
  	}
	alert(url);
	xmlhttp.open("POST",url,true);
	xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	xmlhttp.send("service=" + encodeURI("service"));

}

function setNewScheme(schemeIndex,cartIndex,pricediv,renewchkdiv,cartamount,url){

	xmlhttp=getHTTPObject();
	xmlhttp.onreadystatechange=function(){

		if (xmlhttp.readyState==4 && xmlhttp.status==200){
			var doc = loadXMLString(trim(xmlhttp.responseText));   // Create & Assign the XML file to a var
			var val=doc.getElementsByTagName("CartAmount")[0].childNodes[0].nodeValue;
			cartamount.innerHTML="&nbsp;&nbsp;&nbsp;&nbsp;My Cart:&nbsp;&nbsp;&#x20B9;&nbsp; &nbsp;"+val;
			//new scheme price
			var schemePrice=doc.getElementsByTagName("NewPrice")[0].childNodes[0].nodeValue;
			//reNew flag
			var renewFlag=doc.getElementsByTagName("RenewFlag")[0].childNodes[0].nodeValue;
			
			document.getElementById(pricediv).innerHTML=schemePrice;
			if(renewFlag == 0){
				renewchkdiv.style.display = 'none';  
			}else{
				renewchkdiv.style.display = 'block';  
			}

	    }
  	}
	
	xmlhttp.open("POST",url,true);
	xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	xmlhttp.send("schemeIndex=" + encodeURI(schemeIndex)+ "&cartIndex=" + encodeURI(cartIndex));


}


function setSelectedMac(sltctrl,form){

macID=sltctrl.value;
//var obj = JSON.parse("<?php echo json_encode($_SESSION['logged-in']->balance); ?>");
	xmlhttp=getHTTPObject();
	
	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200){

			/*var doc = loadXMLString(trim(xmlhttp.responseText));   // Create & Assign the XML file to a var
			var val=doc.getElementsByTagName("DistributerAddress")[0].childNodes[0].nodeValue;
			val=val.replace(/`/g,"&");
			distributerAddr.value=val;
			if(form.consumerNo){
			clearConsumerValues(form);
			form.consumerNo.value="";
			}*/
	    }
  	}
	
	xmlhttp.open("POST",url,true);
	xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	xmlhttp.send("macID=" + encodeURI(macID));


}

function getSelectedMac(macid,url){

	xmlhttp=getHTTPObject();
	
	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200){

			var doc = loadXMLString(trim(xmlhttp.responseText));   // Create & Assign the XML file to a var
			var val=doc.getElementsByTagName("MacID")[0].childNodes[0].nodeValue;
			macid.innerHTML=val;
			/*val=val.replace(/`/g,"&");
			distributerAddr.value=val;
			if(form.consumerNo){
			clearConsumerValues(form);
			form.consumerNo.value="";
			}*/
	    }
  	}
	
	xmlhttp.open("POST",url,true);
	xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	xmlhttp.send();


	
}

function getAllSalesAreas(form,url){
	state = form.state.value;
	salesArea = form.salesArea;
	distributer = form.distributer;
	if(form.textfield9)
	distributerAddr = form.textfield9;
	
	if (state==''){
		
		salesArea.options.length=0;
		var val="Select Area";
		var temp = new Option(val,'');
		salesArea.options[salesArea.options.length]=temp;
	

		distributer.options.length=0;
		var val="Select Distributor";
		var temp = new Option(val,'');
		distributer.options[distributer.options.length]=temp;
		if(form.textfield9)
		distributerAddr.value="";
		return;
	}
	xmlhttp=getHTTPObject();
	
	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200){

			var doc = loadXMLString(trim(xmlhttp.responseText));   // Create & Assign the XML file to a var
			salesArea.options.length=0;
			var totchilds=doc.getElementsByTagName("SalesAreaName").length;
			if(totchilds==1 || totchilds>2){
			var val=doc.getElementsByTagName("SalesAreaName")[0].childNodes[0].nodeValue;
			var temp = new Option(val,'');
			salesArea.options[salesArea.options.length]=temp;
			}

			for (i=1;i<totchilds;i++){
				var val=doc.getElementsByTagName("SalesAreaName")[i].childNodes[0].nodeValue;
				val=val.replace(/`/g,"&");
				var temp = new Option(val,val);
				salesArea.options[salesArea.options.length]=temp;
			}
		    if(form.consumerNo){
			clearConsumerValues(form);
			form.consumerNo.value="";
			}
    	}
  	}
	state=state.replace('&','`');
	xmlhttp.open("POST",url,true);
	xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	xmlhttp.send("state=" + encodeURI(state));
}


function getDistributerAddr(form,url){
	
	state = form.state.value;
	salesArea = form.salesArea.value;
	distributer = form.distributer.value;
	distributerAddr = form.textfield9;
	
	if (distributer==""){
		distributerAddr.value="";
		return;
	}
	xmlhttp=getHTTPObject();
	
	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200){

			var doc = loadXMLString(trim(xmlhttp.responseText));   // Create & Assign the XML file to a var
			var val=doc.getElementsByTagName("DistributerAddress")[0].childNodes[0].nodeValue;
			val=val.replace(/`/g,"&");
			distributerAddr.value=val;
			if(form.consumerNo){
			clearConsumerValues(form);
			form.consumerNo.value="";
			}
	    }
  	}
	state=state.replace('&','`');
	salesArea=salesArea.replace('&','`');
	distributer=distributer.replace('&','`');

	xmlhttp.open("POST",url,true);
	xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	xmlhttp.send("state=" + encodeURI(state) + "&salesArea=" + encodeURI(salesArea) + "&distributer=" + encodeURI(distributer));
}

function getCenterDetails(form,url){

	usercode = trim(form.usercode.value);
	if (usercode==""){
		document.getElementById("error").innerHTML="Please Enter Subscriber Code";
		return;
	}

	xmlhttp=getHTTPObject();
	
	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200){
			var doc = loadXMLString(trim(xmlhttp.responseText));   // Create & Assign the XML file to a var
			var status=doc.getElementsByTagName("Status")[0].childNodes[0].nodeValue;
			if(status==1){
			form.centername.value=doc.getElementsByTagName("CenterName")[0].childNodes[0].nodeValue;
			form.subname.value=doc.getElementsByTagName("SubscriberName")[0].childNodes[0].nodeValue;
			if(document.getElementById("error"))
			document.getElementById("error").innerHTML="";
			}
			else{
			form.centername.value="";
			if(document.getElementById("error"))
			document.getElementById("error").innerHTML=doc.getElementsByTagName("Remarks")[0].childNodes[0].nodeValue;
			}

    	}
  	}
	
	xmlhttp.open("POST",url,true);
	xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	xmlhttp.send("usercode=" + encodeURI(usercode));
}

function getConsumerData(form,url){

	consumerno = trim(form.consumerNo.value);
	distributer = form.distributer.value;
	
	
	if (distributer==""){
		document.getElementById("error").innerHTML="Please Select Distributor";
		return;
	}
	else if (consumerno==""){
		document.getElementById("error").innerHTML="Please Enter Consumer No";
		return;
	}

	xmlhttp=getHTTPObject();
	
	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200){

			var doc = loadXMLString(trim(xmlhttp.responseText));   // Create & Assign the XML file to a var
			var val=doc.getElementsByTagName("Status")[0].childNodes[0].nodeValue;

			if(val=="1"){
				if(doc.getElementsByTagName("ConsumerName")[0].hasChildNodes())
				form.consumerName.value=doc.getElementsByTagName("ConsumerName")[0].childNodes[0].nodeValue;
				if(doc.getElementsByTagName("Email")[0].hasChildNodes()){
					form.emailId.value=doc.getElementsByTagName("Email")[0].childNodes[0].nodeValue;
					//form.emailId.readOnly=true;
				}
				//else
					//form.emailId.readOnly=false;
				form.category.value=doc.getElementsByTagName("Category")[0].childNodes[0].nodeValue;
				if(doc.getElementsByTagName("Mobile")[0].hasChildNodes()){
					form.mobileNo.value=doc.getElementsByTagName("Mobile")[0].childNodes[0].nodeValue;
					form.mobileNo.readOnly=true;
				}
				else
					form.mobileNo.readOnly=false;
				if(doc.getElementsByTagName("Mobile1")[0].hasChildNodes()){
					form.landMob1.value=doc.getElementsByTagName("Mobile1")[0].childNodes[0].nodeValue;
					form.landMob1.readOnly=true;
				}
				else
					form.landMob1.readOnly=false;
				if(doc.getElementsByTagName("Mobile2")[0].hasChildNodes()){
					form.landMob2.value=doc.getElementsByTagName("Mobile2")[0].childNodes[0].nodeValue;
					form.landMob2.readOnly=true;
				}
				else
					form.landMob2.readOnly=false;
				document.getElementById("error").innerHTML="";
			}
			else{
				clearConsumerValues(form);
				document.getElementById("error").innerHTML=doc.getElementsByTagName('Error').item(0).firstChild.data;
			}
			

    	}
  	}
	
	xmlhttp.open("POST",url,true);
	xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	xmlhttp.send("distributer=" + encodeURI(distributer) + "&consumerno=" + encodeURI(consumerno));
}
function clearConsumerValues(form)
{
		
		form.consumerName.value="";
		form.category.value="";
		form.emailId.value="";
		form.mobileNo.value="";
		form.landMob1.value="";
		form.landMob2.value="";
		form.password.value="";
		form.password2.value="";
		
}

function getPasswordInfo(form,userName,userType,url){
	if (userName=="" || userType == ""){
		return;
	}

	xmlhttp=getHTTPObject();
	
	xmlhttp.onreadystatechange=function(){
		if (xmlhttp.readyState==4 && xmlhttp.status==200){

			var doc = loadXMLString(trim(xmlhttp.responseText));   // Create & Assign the XML file to a var
			var val=doc.getElementsByTagName("Status")[0].childNodes[0].nodeValue;
			if(val=="1"){
				if(doc.getElementsByTagName("email")[0].hasChildNodes()){
					form.email.value=doc.getElementsByTagName("email")[0].childNodes[0].nodeValue;
					form.email.readOnly=true;
				}
				else
					form.email.readOnly=false;
			}
			else{
				if(doc.getElementsByTagName("Error")[0].hasChildNodes()){
					document.getElementById("error").innerHTML=doc.getElementsByTagName("Error")[0].childNodes[0].nodeValue;
					form.email.value="";
					form.email.readOnly=false;
				}
				
			}
    	}
  	}
	
	xmlhttp.open("POST",url,true);
	xmlhttp.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
	xmlhttp.send("userName=" + encodeURI(userName) + "&userType=" + encodeURI(userType)); 
}

function submitform(value){
	document.myForm.start.value = value;
	document.myForm.submit();
}

function submitform1(value){
	document.myForm.start1.value = value;
	document.myForm.submit();
}

function submitform2(value){
	document.myForm.start2.value = value;
	document.myForm.submit();
}




