/*function mmLoadMenus(appPath) {
	if (window.officer_bookingReport) return;
	//if (window.officer_bookingDetails) return;
	
	
	window.officer_bookingReport = new Menu("root",170,24,"Tahoma, Verdana",11,"#ffffff","#000000","#5071c5","#ff6f04","left","middle",3,0,300,-5,7,true,true,true,0,true,true);
	
	officer_bookingReport.addMenuItem("Daily Booking Report","location='"+appPath+"officer/dailyBookingReport'");
	officer_bookingReport.addMenuItem("Monthly Booking Report","location='"+appPath+"officer/monthlyBookingReport'");
	officer_bookingReport.addMenuItem("Booking Summary Report","location='"+appPath+"officer/bookingReportSummary'");
	
	officer_bookingReport.writeMenus();

	window.officer_bookingDetails = new Menu("root",170,24,"Tahoma, Verdana",11,"#ffffff","#000000","#5071c5","#ff6f04","left","middle",3,0,300,-5,7,true,true,true,0,true,true);
	
	officer_bookingDetails.addMenuItem("Daily Booking Report","location='"+appPath+"officer/dailyBookingReport'");
	officer_bookingDetails.addMenuItem("Monthly Booking Report","location='"+appPath+"officer/monthlyBookingReport'");
	officer_bookingDetails.addMenuItem("Booking Summary Report","location='"+appPath+"officer/bookingReportSummary'");
	
	officer_bookingReport.writeMenus();

} // mmLoadMenus() */

var timeout	= 500;
var closetimer	= 0;
var ddmenuitem	= 0;

// open hidden layer
function mopen(id)
{	
	// cancel close timer
	mcancelclosetime();

	// close old layer
	if(ddmenuitem) ddmenuitem.style.visibility = 'hidden';

	// get new layer and show it
	ddmenuitem = document.getElementById(id);
	ddmenuitem.style.visibility = 'visible';

}
// close showed layer
function mclose()
{
	if(ddmenuitem) ddmenuitem.style.visibility = 'hidden';
}

// go close timer
function mclosetime()
{
	closetimer = window.setTimeout(mclose, timeout);
}

// cancel close timer
function mcancelclosetime()
{
	if(closetimer)
	{
		window.clearTimeout(closetimer);
		closetimer = null;
	}
}

// close layer when click-out
document.onclick = mclose; 

