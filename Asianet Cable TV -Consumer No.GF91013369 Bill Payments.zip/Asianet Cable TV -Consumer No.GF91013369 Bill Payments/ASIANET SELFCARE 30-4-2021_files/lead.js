function loadDropDown(id, url, val) {
	
	$.ajax({
		type : "POST",
		url : url,
		dataType : 'json',
		success : function(data) {
			displayDropDown(id, data, val)
		},
		error : function(error) {
			console.log("load DD id:::" + id);
			console.log("ERRROR:::" + error);
		},
	});
}

function displayDropDown(id, data, val) {
	// $("#"+id).get(0).options.length=0;
	
	console.log('Display drop down value::::',data)
	
	$("#" + id).empty();

	if (id != undefined) {
		$("#" + id).get(0).options[$("#" + id).get(0).options.length] = new Option(
				"Please Select", "Please Select")
		
				$.each(
						data,
						function(key, value) {
							$("#" + id).get(0).options[$("#" + id).get(0).options.length] = new Option(
									value, value)
						});
		if (val != '')
			$("#" + id).val(val);

		if ($($("#" + id + " Option")[1]).val() == "[object Object]") {
			$("#" + id).empty();
			var op = "<option>Please Select</option>";
			$.each(data, function(key, value) {
				op += "<option value='" + value.userId +"$"+value.userName+"'>" + value.userName
						+ "</option>";
			});
			$("#" + id).append(op);
			if (val != '')
				$("#" + id).val(val);

			// $("#"+id).attr({"data-show-subtext":"true","data-live-search":"true","class":"selectpicker
			// form-control"});
			//$("#" + id).selectpicker('refresh');

		}
	} else {
		console.log("displayDropDown id:::" + id);
	}

}
function compareDate() {
	if ($('#leadFromDate').val() != null && $('#leadFromDate').val() != '') {

		var startDate = $('#leadFromDate').val().split("-");
		startDate = new Date(startDate[1] + "/" + startDate[0] + "/"
				+ startDate[2]);

		if ($('#leadToDate').val() != null && $('#leadToDate').val() != '') {

			var endDate = $('#leadToDate').val().split("-");
			endDate = new Date(endDate[1] + "/" + endDate[0] + "/" + endDate[2]);

			if (startDate > endDate) {
				// Do something
				alert("From Date cannot be more than to Date");
				return false;
			}

		}
	}
	return true;
}
function onlyAlphaNumeric(event) {

	var regex = new RegExp("[a-zA-Z0-9]");
	var key = String.fromCharCode(!event.charCode ? event.which
			: event.charCode);
	var ignoredKeys = [ 8, 9 ];
	if (ignoredKeys.indexOf(event.which) >= 0)
		return true;
	if (!regex.test(key)) {
		// event.preventDefault();
		return false;
	} else
		return true;

}
function onlyAlphaNumericCharac(event) {

	var regex = new RegExp("[a-zA-Z0-9 ,-]");
	var key = String.fromCharCode(!event.charCode ? event.which
			: event.charCode);
	var ignoredKeys = [ 8, 9 ];
	if (ignoredKeys.indexOf(event.which) >= 0)
		return true;
	if (!regex.test(key)) {
		// event.preventDefault();
		return false;
	} else
		return true;

}
function onlyAlpha(event) {

	var regex = new RegExp("[a-zA-Z]");
	var key = String.fromCharCode(!event.charCode ? event.which
			: event.charCode);
	var ignoredKeys = [ 8, 9 ];
	if (ignoredKeys.indexOf(event.which) >= 0)
		return true;
	if (!regex.test(key)) {
		// event.preventDefault();
		return false;
	} else
		return true;

}
function onlyPhoneNumeric(event) {

	var regex = new RegExp("[0-9-+]");
	var key = String.fromCharCode(!event.charCode ? event.which
			: event.charCode);
	var ignoredKeys = [ 8, 9 ];
	if (ignoredKeys.indexOf(event.which) >= 0)
		return true;
	if (!regex.test(key)) {
		// event.preventDefault();
		return false;
	} else
		return true;

}
function onlyNumeric(event) {

	var regex = new RegExp("[0-9]");
	var key = String.fromCharCode(!event.charCode ? event.which
			: event.charCode);
	var ignoredKeys = [ 8, 9 ];
	if (ignoredKeys.indexOf(event.which) >= 0)
		return true;
	if (!regex.test(key)) {
		// event.preventDefault();
		return false;
	} else
		return true;

}
function onlyAmount(id,event) {

	var regex = new RegExp("[0-9.]");
	var key = String.fromCharCode(!event.charCode ? event.which
			: event.charCode);
	var idVal = $("#" + id).val();
	if(idVal.indexOf(".") > -1 && key == ".")
		return false;
	var ignoredKeys = [ 8, 9 ];
	if (ignoredKeys.indexOf(event.which) >= 0)
		return true;
	if (!regex.test(key)) {
		// event.preventDefault();
		return false;
	} else
		return true;

}
function onlyEmailCharac(event) {

	var regex = new RegExp("[a-zA-Z0-9@._$#&]");
	var key = String.fromCharCode(!event.charCode ? event.which
			: event.charCode);
	var ignoredKeys = [ 8, 9 ];
	if (ignoredKeys.indexOf(event.which) >= 0)
		return true;
	if (!regex.test(key)) {
		// event.preventDefault();
		return false;
	} else
		return true;

}
function onlyMACAddr(event) {

	var regex = new RegExp("[a-zA-Z0-9:]");
	var key = String.fromCharCode(!event.charCode ? event.which
			: event.charCode);
	var ignoredKeys = [ 8, 9 ];
	if (ignoredKeys.indexOf(event.which) >= 0)
		return true;
	if (!regex.test(key)) {
		// event.preventDefault();
		return false;
	} else
		return true;

}

function isValidEmailAddress(emailAddress) {
	var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
	return pattern.test(emailAddress);
}
function validatePhone(txtPhone) {
	var a = document.getElementById(txtPhone).value;
	var filter = /^((\+[1-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/;
	if (filter.test(a)) {
		return true;
	} else {
		return false;
	}
}
function initLead() {
	loadDropDown('serviceType', 'getLeadServiceTypeList', 'Please Select');
	loadDropDown('accountType', 'getAccountTypeList', 'Please Select');
	loadDropDown('connectionType', 'getConnectionTypeList', 'Please Select');
	loadDropDown('customerType', 'getCustomerTypeList', 'Please Select');
	loadDropDown('salutation', 'getSalutationList', 'Please Select');
	loadDropDown('qCustomerType', 'getCustomerTypeList', 'Please Select');
	loadDropDown('qSalutation', 'getSalutationList', 'Please Select');
	loadDropDown('qServiceType', 'getLeadServiceTypeList', 'Please Select');
	loadDropDown('leadSource', 'getSourceList', 'Please Select');
	loadDropDown('channel', 'getChannelList', 'Please Select');
	loadDropDown('noOfConnection', 'getNoOfConnectionList', 'Please Select');

}
function onlyAlphaCharac(event) {

	var regex = new RegExp("[a-zA-Z ]");
	var key = String.fromCharCode(!event.charCode ? event.which
			: event.charCode);
	var ignoredKeys = [ 8, 9 ];
	if (ignoredKeys.indexOf(event.which) >= 0)
		return true;
	if (!regex.test(key)) {
		// event.preventDefault();
		return false;
	} else
		return true;

}


//number to string
function convertNumberToWords(amount) {
    var words = new Array();
    words[0] = '';
    words[1] = 'One';
    words[2] = 'Two';
    words[3] = 'Three';
    words[4] = 'Four';
    words[5] = 'Five';
    words[6] = 'Six';
    words[7] = 'Seven';
    words[8] = 'Eight';
    words[9] = 'Nine';
    words[10] = 'Ten';
    words[11] = 'Eleven';
    words[12] = 'Twelve';
    words[13] = 'Thirteen';
    words[14] = 'Fourteen';
    words[15] = 'Fifteen';
    words[16] = 'Sixteen';
    words[17] = 'Seventeen';
    words[18] = 'Eighteen';
    words[19] = 'Nineteen';
    words[20] = 'Twenty';
    words[30] = 'Thirty';
    words[40] = 'Forty';
    words[50] = 'Fifty';
    words[60] = 'Sixty';
    words[70] = 'Seventy';
    words[80] = 'Eighty';
    words[90] = 'Ninety';
    amount = amount.toString();
    var atemp = amount.split(".");
    var number = atemp[0].split(",").join("");
    var n_length = number.length;
    var words_string = "";
    if (n_length <= 9) {
        var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
        var received_n_array = new Array();
        for (var i = 0; i < n_length; i++) {
            received_n_array[i] = number.substr(i, 1);
        }
        for (var i = 9 - n_length, j = 0; i < 9; i++, j++) {
            n_array[i] = received_n_array[j];
        }
        for (var i = 0, j = 1; i < 9; i++, j++) {
            if (i == 0 || i == 2 || i == 4 || i == 7) {
                if (n_array[i] == 1) {
                    n_array[j] = 10 + parseInt(n_array[j]);
                    n_array[i] = 0;
                }
            }
        }
        value = "";
        for (var i = 0; i < 9; i++) {
            if (i == 0 || i == 2 || i == 4 || i == 7) {
                value = n_array[i] * 10;
            } else {
                value = n_array[i];
            }
            if (value != 0) {
                words_string += words[value] + " ";
            }
            if ((i == 1 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)) {
                words_string += "Crores ";
            }
            if ((i == 3 && value != 0) || (i == 2 && value != 0 && n_array[i + 1] == 0)) {
                words_string += "Lakhs ";
            }
            if ((i == 5 && value != 0) || (i == 4 && value != 0 && n_array[i + 1] == 0)) {
                words_string += "Thousand ";
            }
            if (i == 6 && value != 0 && (n_array[i + 1] != 0 && n_array[i + 2] != 0)) {
                words_string += "Hundred and ";
            } else if (i == 6 && value != 0) {
                words_string += "Hundred ";
            }
        }
        words_string = words_string.split("  ").join(" ");
    }
    return words_string;
}


function getAmountToShow(amt) {
	
  var str =new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 }).format(amt);
  var res = str.slice(0);
  return res;
}


// convert number to word with decimal


function Rs(amount){
	var words = new Array();
	words[0] = 'Zero';words[1] = 'One';words[2] = 'Two';words[3] = 'Three';words[4] = 'Four';words[5] = 'Five';words[6] = 'Six';words[7] = 'Seven';words[8] = 'Eight';words[9] = 'Nine';words[10] = 'Ten';words[11] = 'Eleven';words[12] = 'Twelve';words[13] = 'Thirteen';words[14] = 'Fourteen';words[15] = 'Fifteen';words[16] = 'Sixteen';words[17] = 'Seventeen';words[18] = 'Eighteen';words[19] = 'Nineteen';words[20] = 'Twenty';words[30] = 'Thirty';words[40] = 'Forty';words[50] = 'Fifty';words[60] = 'Sixty';words[70] = 'Seventy';words[80] = 'Eighty';words[90] = 'Ninety';var op;
	amount = amount.toString();
	var atemp = amount.split(".");
	var number = atemp[0].split(",").join("");
	var n_length = number.length;
	var words_string = "";
	if(n_length <= 9){
	var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
	var received_n_array = new Array();
	for (var i = 0; i < n_length; i++){
	received_n_array[i] = number.substr(i, 1);}
	for (var i = 9 - n_length, j = 0; i < 9; i++, j++){
	n_array[i] = received_n_array[j];}
	for (var i = 0, j = 1; i < 9; i++, j++){
	if(i == 0 || i == 2 || i == 4 || i == 7){
	if(n_array[i] == 1){
	n_array[j] = 10 + parseInt(n_array[j]);
	n_array[i] = 0;}}}
	value = "";
	for (var i = 0; i < 9; i++){
	if(i == 0 || i == 2 || i == 4 || i == 7){
	value = n_array[i] * 10;} else {
	value = n_array[i];}
	if(value != 0){
	words_string += words[value] + " ";}
	if((i == 1 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)){
	words_string += "Crores ";}
	if((i == 3 && value != 0) || (i == 2 && value != 0 && n_array[i + 1] == 0)){
	words_string += "Lakhs ";}
	if((i == 5 && value != 0) || (i == 4 && value != 0 && n_array[i + 1] == 0)){
	words_string += "Thousand ";}
	if(i == 6 && value != 0 && (n_array[i + 1] != 0 && n_array[i + 2] != 0)){
	words_string += "Hundred and ";} else if(i == 6 && value != 0){
	words_string += "Hundred ";}}
	words_string = words_string.split(" ").join(" ");}
	return words_string;}
	function RsPaise(n){
	nums = n.toString().split('.')
	var whole = Rs(nums[0])
	if(nums[1]==null)nums[1]=0;
	if(nums[1].length == 1 )nums[1]=nums[1]+'0';
	if(nums[1].length> 2){nums[1]=nums[1].substring(2,length - 1)}
	if(nums.length == 2){
	if(nums[0]<=9){nums[0]=nums[0]*10} else {nums[0]=nums[0]};
	var fraction = Rs(nums[1])
	if(whole=='' && fraction==''){op= 'Zero only';}
	if(whole=='' && fraction!=''){op= 'paise ' + fraction + ' only';}
	if(whole!='' && fraction==''){op='Rupees ' + whole + ' only';} 
	if(whole!='' && fraction!=''){op='Rupees ' + whole + 'and paise ' + fraction + ' only';}
	amt=n;
	if(amt > 999999999.99){op='Oops!!! The amount is too big to convert';}
	if(isNaN(amt) == true ){op='Error : Amount in number appears to be incorrect. Please Check.';} 
	return op;}
	}
	//RsPaise(Math.round(document.getElementById('amt').value*100)/100);
 
 